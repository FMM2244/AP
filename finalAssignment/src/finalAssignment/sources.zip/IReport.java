package finalAssignment;

public interface IReport {
	IReport generateReport();
	void Display();
}
