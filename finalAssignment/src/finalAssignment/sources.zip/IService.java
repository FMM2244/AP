package finalAssignment;

public interface IService {
	void printServicePrompt();
	void setUser(Employee currentUser);
}
