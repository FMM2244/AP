package com.finalassignment;

public interface IService {
	void printServicePrompt(int option);
}

