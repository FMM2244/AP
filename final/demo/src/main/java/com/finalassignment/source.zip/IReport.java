package com.finalassignment;

public interface IReport {
	IReport generateReport();
	void Display();
}
