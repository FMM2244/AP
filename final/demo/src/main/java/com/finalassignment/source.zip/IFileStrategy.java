/**
 * this is the file
 */
package com.finalassignment;

public interface IFileStrategy {
	String [] read();
	void write(String input);
}
